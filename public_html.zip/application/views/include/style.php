<link rel="stylesheet" href="<?php echo base_url('/inti/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/animations.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/regular.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/brands.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/solid.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/fontawesome.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/font-awesome.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/css-main.css'); ?>" class="color-switcher-link">
<link rel="stylesheet" href="<?php echo base_url('/inti/css/shop.css'); ?>" class="color-switcher-link">