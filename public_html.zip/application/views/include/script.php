<script src="<?php echo base_url('/inti/js/compressed.js'); ?>"></script>
<script src="<?php echo base_url('/inti/js/main1.js'); ?>"></script>
<!-- <script src="<?php echo base_url('/inti/js/switcher.js'); ?>"></script> -->