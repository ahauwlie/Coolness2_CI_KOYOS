<footer class="page_footer ds s-pt-77 s-pb-40 c-gutter-150">
	<div class="container">
		<div class="row">
			<div class="divider-20 d-none d-xl-block"></div>
			<div class="col-md-6 animate" data-animation="fadeInUp">
				<div class="widget widget_text">
					<img src="<?php echo base_url('/inti/images/logo1.png'); ?>" alt="">
					<p>
						moto.
					</p>
					<div class="divider-20 d-none d-xl-block"></div>
					<div class="fw-divider-special">
						<p class="special"></p>
					</div>
					<div class="divider-25 d-none d-xl-block"></div>
					<div class="widget widget_social_buttons">
						<a href="#" class="fa fa-facebook" title="facebook"></a>
						<a href="#" class="fa fa-twitter" title="twitter"></a>
						<a href="#" class="fa fa-google" title="google"></a>
						<a href="#" class="fa fa-youtube-play" title="youtube-play"></a>
						<a href="#" class="fa fa-rss" title="rss"></a>
					</div>
				</div>
			</div>
			<div class="col-md-6 animate" data-animation="fadeInUp">
				<div class="widget widget_icons_list">
					<h3>Contacts</h3>
					<div class="media side-icon-box">
						<div class="icon-styled color-main fs-14">
							<i class="ico icon-map-pin-silhouette"></i>
						</div>
						<p class="media-body">alamat</p>
					</div>
					<div class="media side-icon-box">
						<div class="icon-styled color-main fs-14">
							<i class="ico icon-phone-receiver"></i>
						</div>
						<p class="media-body"> no hp <span> no hp</span></p>
					</div>
					<div class="media side-icon-box">
						<div class="icon-styled color-main fs-14">
							<i class="fa fa-envelope"></i>
						</div>
						<p class="media-body">
							<a href="#">email</a>
						</p>
					</div>
				</div>
			</div>
			<!-- <div class="col-md-4 animate" data-animation="fadeInUp">
				<div class="widget widget_recent_posts">
					<h3 class="widget-title">Recent Posts</h3>
					<ul class="list-unstyled">
						<li class="media">
							<a class="media-image" href="blog-single-right.html">
							<img src="<?php echo base_url('/inti/images/events/01.jpg'); ?>" alt="">
							</a>
							<div class="media-body">
								<h4>
									<a href="#">Eod tempor invidunt labore dolore magna</a>
								</h4>
								<p class="item-meta">
									Tanggal
								</p>
							</div>
						</li>
						<li class="media">
							<a class="media-image" href="blog-single-right.html">
							<img src="<?php echo base_url('/inti/images/events/02.jpg'); ?>" alt="">
							</a>
							<div class="media-body">
								<h4>
									<a href="#">Aliquyam erat, sed voluptua vero eos </a>
								</h4>
								<p class="item-meta">
									Tanggal
								</p>
							</div>
						</li>
					</ul>
				</div>
			</div> -->
			<div class="divider-40 d-none d-xl-block"></div>
		</div>
	</div>
</footer>